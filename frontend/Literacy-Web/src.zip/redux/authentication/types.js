// Login
export const LOGIN = "LOGIN";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAILURE = "LOGIN_FAILURE";
// check sessions
export const USER_VERIFICATION = "USER_VERIFICATION";
export const USER_VERIFICATION_SUCCESS = "USER_VERIFICATION_SUCCESS";
export const USER_VERIFICATION_FAILURE = "USER_VERIFICATION_FAILURE";
// Logout
export const LOGOUT = "LOGOUT";
